/*!
 * Author: mosaicpro.biz
 * Licence: Commercial (http://themeforest.net/licenses)
 * Copyright 2014
 */

module.exports = function (grunt) {
    require('time-grunt')(grunt);
    grunt.loadTasks('lib/grunt/tasks');
};